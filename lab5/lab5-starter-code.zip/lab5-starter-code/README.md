Code for CSO1 simulator lab; see [the course website](https://researcher111.github.io/uva-cso1-F23-DG/labs/lab5-simulator.html) for more.

All example inputs on the writeup are also provided in the `programs/` directory.
